package com.spring.ai.firstproject.controllers;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ChatController {

    private final ChatClient openAiChatClient;

    public ChatController(
            @Qualifier("openAiChatClient") ChatClient openAiChatClient) {
        this.openAiChatClient = openAiChatClient;
    }

    @GetMapping("/chat")
    public String chat(@RequestParam String message) {
        return openAiChatClient.prompt()
                .user(message)
                .call()
                .content();
    }
}
